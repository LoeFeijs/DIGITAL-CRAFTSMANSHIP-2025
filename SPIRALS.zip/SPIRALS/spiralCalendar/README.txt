Linedrawings gft, pmd, rest, and papier are made by Photoshop and editing of the
originals in https://rwm.nl/wanneer (RWM afval kalender Sittard).

Limitation: day 1 is assumed to be a monday (like september 2025)